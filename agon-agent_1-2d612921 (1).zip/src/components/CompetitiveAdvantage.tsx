import { Check, X } from 'lucide-react';

export default function CompetitiveAdvantage() {
  return (
    <section className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Unfair Advantage</h2>
          <p className="text-gray-400 text-lg">Why PoultryLink wins in the East African market.</p>
        </div>

        <div className="max-w-4xl mx-auto overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr>
                <th className="p-4 border-b border-white/10 text-gray-400 font-medium">Feature</th>
                <th className="p-4 border-b border-white/10 text-gray-400 font-medium">Traditional Brokers</th>
                <th className="p-4 border-b border-white/10 text-gray-400 font-medium">Generic AgTech</th>
                <th className="p-4 border-b border-[#D4AF37] text-[#D4AF37] font-bold text-lg bg-[#0B3D2E]/20 rounded-t-xl">PoultryLink</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: "Escrow Payments", b: false, a: false, p: true },
                { name: "WhatsApp Native UX", b: true, a: false, p: true },
                { name: "Cold-Chain Logistics", b: false, a: false, p: true },
                { name: "Traceability & Health Certs", b: false, a: false, p: true },
                { name: "Price Transparency", b: false, a: true, p: true },
              ].map((row, i) => (
                <tr key={i} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-4 font-medium">{row.name}</td>
                  <td className="p-4">{row.b ? <Check className="text-gray-500 w-5 h-5" /> : <X className="text-red-500/50 w-5 h-5" />}</td>
                  <td className="p-4">{row.a ? <Check className="text-gray-500 w-5 h-5" /> : <X className="text-red-500/50 w-5 h-5" />}</td>
                  <td className="p-4 bg-[#0B3D2E]/10"><Check className="text-[#25D366] w-6 h-6" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
