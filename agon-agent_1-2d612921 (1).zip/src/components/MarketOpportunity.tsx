import { motion } from 'framer-motion';

export default function MarketOpportunity() {
  return (
    <section className="py-24 relative" id="market">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Massive Market Opportunity</h2>
          <p className="text-gray-400 text-lg">Kenya's poultry sector is large, growing rapidly, and ripe for digital transformation.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="glass-panel p-8 text-center"
          >
            <div className="text-4xl md:text-5xl font-bold text-[#D4AF37] mb-2">KSh 26.3B</div>
            <div className="text-lg font-medium text-white mb-2">Market Size</div>
            <p className="text-sm text-gray-400">Annual valuation of the Kenyan commercial poultry sector.</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="glass-panel p-8 text-center"
          >
            <div className="text-4xl md:text-5xl font-bold text-[#D4AF37] mb-2">105k MT</div>
            <div className="text-lg font-medium text-white mb-2">Annual Production</div>
            <p className="text-sm text-gray-400">Metric tons of poultry meat produced annually to meet demand.</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="glass-panel p-8 text-center"
          >
            <div className="text-4xl md:text-5xl font-bold text-[#D4AF37] mb-2">8.2%</div>
            <div className="text-lg font-medium text-white mb-2">YoY Growth</div>
            <p className="text-sm text-gray-400">Driven by urbanization and rising middle-class protein consumption.</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
