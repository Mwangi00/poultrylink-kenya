export default function Traction() {
  return (
    <section className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Target Metrics & Traction</h2>
          <p className="text-gray-400 text-lg">Our Year 1 projections based on current pilot programs in Nairobi and Kiambu.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
          <div className="glass-panel p-6 text-center border-t-4 border-t-[#D4AF37]">
            <div className="text-3xl md:text-4xl font-bold text-white mb-2">KSh 50M</div>
            <div className="text-sm text-gray-400">Target Annual GMV</div>
          </div>
          <div className="glass-panel p-6 text-center border-t-4 border-t-[#0B3D2E]">
            <div className="text-3xl md:text-4xl font-bold text-white mb-2">50+</div>
            <div className="text-sm text-gray-400">Premium B2B Buyers</div>
          </div>
          <div className="glass-panel p-6 text-center border-t-4 border-t-[#D4AF37]">
            <div className="text-3xl md:text-4xl font-bold text-white mb-2">500+</div>
            <div className="text-sm text-gray-400">Verified Farmers</div>
          </div>
          <div className="glass-panel p-6 text-center border-t-4 border-t-[#0B3D2E]">
            <div className="text-3xl md:text-4xl font-bold text-white mb-2">0%</div>
            <div className="text-sm text-gray-400">Payment Default Rate</div>
          </div>
        </div>
      </div>
    </section>
  );
}
