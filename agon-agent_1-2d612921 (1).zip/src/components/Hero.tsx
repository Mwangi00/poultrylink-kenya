import { motion } from 'framer-motion';
import { ArrowRight, ShieldCheck, TrendingUp, Smartphone } from 'lucide-react';

export default function Hero({ onOpenModal }: { onOpenModal: (type: any) => void }) {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-[#0B3D2E] rounded-full blur-[120px] opacity-30 -z-10" />
      
      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm text-[#D4AF37] mb-6">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" />
            East Africa's First Verified Poultry Marketplace
          </div>
          
          <h1 className="text-5xl lg:text-7xl font-bold leading-tight mb-6 text-white">
            Reliable Poultry.<br />
            <span className="gold-gradient-text">Delivered.</span>
          </h1>
          
          <p className="text-lg text-gray-400 mb-10 leading-relaxed">
            Connecting smallholder farmers to premium buyers—hotels, restaurants, and exporters—through trusted digital trade, M-Pesa escrow, and verified logistics.
          </p>
          
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <button onClick={() => onOpenModal('buyer')} className="bg-[#0B3D2E] hover:bg-[#0d4d3a] text-white px-8 py-4 rounded-full font-medium transition-all flex items-center gap-2 border border-[#1a5c48] shadow-[0_0_20px_rgba(11,61,46,0.5)] hover:shadow-[0_0_30px_rgba(11,61,46,0.7)]">
              Get Started <ArrowRight className="w-5 h-5" />
            </button>
            <button onClick={() => onOpenModal('investor')} className="bg-white/5 hover:bg-white/10 text-white px-8 py-4 rounded-full font-medium transition-all flex items-center gap-2 border border-white/10">
              Download Investor Deck
            </button>
          </div>
          
          <div className="flex items-center gap-8 pt-6 border-t border-white/10">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm text-gray-400">M-Pesa Escrow</span>
            </div>
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm text-gray-400">WhatsApp Native</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm text-gray-400">Verified Suppliers</span>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="relative lg:h-[600px] flex items-center justify-center"
        >
          <div className="relative w-full max-w-md mx-auto aspect-[9/16] glass-panel p-2 green-glow">
            <div className="w-full h-full bg-[#050505] rounded-xl overflow-hidden border border-white/5 relative flex flex-col">
              <div className="p-4 border-b border-white/10 flex justify-between items-center bg-[#0A0A0A]">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-[#25D366] flex items-center justify-center">
                    <Smartphone className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-sm font-medium">PoultryLink Bot</span>
                </div>
                <div className="w-2 h-2 rounded-full bg-[#25D366]" />
              </div>
              
              <div className="flex-1 p-4 flex flex-col gap-4 bg-[#0A0A0A] overflow-hidden opacity-80">
                <div className="self-start max-w-[85%] bg-[#1a1a1a] p-3 rounded-2xl rounded-tl-none border border-white/5 text-sm">
                  Hello! I need 50 kgs of Grade A chicken for Serena Hotel tomorrow.
                </div>
                <div className="self-end max-w-[85%] bg-[#0B3D2E] p-3 rounded-2xl rounded-tr-none border border-[#1a5c48] text-sm">
                  Confirmed. We have 3 verified farmers in Kiambu ready to supply. Total: KSh 22,500.
                </div>
                <div className="self-start max-w-[85%] bg-[#1a1a1a] p-3 rounded-2xl rounded-tl-none border border-white/5 text-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                    <span className="font-medium text-[#D4AF37]">Escrow Link Generated</span>
                  </div>
                  Please pay via M-Pesa to secure the order. Funds are held until delivery is confirmed.
                </div>
                <div className="self-end max-w-[85%] bg-[#0B3D2E] p-3 rounded-2xl rounded-tr-none border border-[#1a5c48] text-sm">
                  Paid. Transaction ID: RKG8392M.
                </div>
                <div className="mt-auto self-center bg-white/5 px-4 py-2 rounded-full text-xs text-gray-400 border border-white/10 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  Logistics partner dispatched
                </div>
              </div>
            </div>
            
            <motion.div 
              animate={{ y: [0, -10, 0] }} 
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="absolute -right-12 top-20 glass-panel p-3 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-full bg-[#25D366]/20 flex items-center justify-center text-[#25D366]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-gray-400">Payment</div>
                <div className="text-sm font-bold text-white">Secured</div>
              </div>
            </motion.div>
            
            <motion.div 
              animate={{ y: [0, 10, 0] }} 
              transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
              className="absolute -left-12 bottom-32 glass-panel p-3 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-gray-400">Order Status</div>
                <div className="text-sm font-bold text-white">In Transit</div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
