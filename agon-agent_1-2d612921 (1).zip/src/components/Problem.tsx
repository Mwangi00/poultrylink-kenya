import { AlertCircle, TrendingDown, ShieldAlert, ArrowRight } from 'lucide-react';

export default function Problem() {
  return (
    <section className="py-24 bg-[#050505] border-y border-white/5" id="problem">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">A Broken Supply Chain</h2>
          <p className="text-gray-400 text-lg">
            The traditional poultry market in East Africa is highly fragmented, inefficient, and lacks trust.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="glass-panel p-8">
            <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center mb-6 border border-red-500/20">
              <TrendingDown className="w-6 h-6 text-red-500" />
            </div>
            <h3 className="text-xl font-bold mb-3">Farmers Lose Out</h3>
            <p className="text-gray-400">Middlemen and brokers extract 30–40% of the margin, leaving smallholder farmers in poverty despite high demand.</p>
          </div>
          
          <div className="glass-panel p-8">
            <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center mb-6 border border-orange-500/20">
              <AlertCircle className="w-6 h-6 text-orange-500" />
            </div>
            <h3 className="text-xl font-bold mb-3">Unreliable Supply</h3>
            <p className="text-gray-400">Hotels and butcheries face inconsistent quality, unpredictable volumes, and sudden price spikes.</p>
          </div>
          
          <div className="glass-panel p-8">
            <div className="w-12 h-12 rounded-xl bg-yellow-500/10 flex items-center justify-center mb-6 border border-yellow-500/20">
              <ShieldAlert className="w-6 h-6 text-yellow-500" />
            </div>
            <h3 className="text-xl font-bold mb-3">Zero Trust</h3>
            <p className="text-gray-400">No traceability, no quality assurance, and high risk of payment defaults for both buyers and sellers.</p>
          </div>
        </div>

        <div className="mt-16 glass-panel p-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-red-500/5" />
          <div className="relative flex flex-col md:flex-row items-center justify-between gap-4 text-center">
            <div className="flex-1">
              <div className="w-16 h-16 mx-auto rounded-full bg-white/10 flex items-center justify-center mb-3">
                <span className="text-2xl">👨🏽‍🌾</span>
              </div>
              <div className="font-medium">Farmer</div>
              <div className="text-xs text-red-400 mt-1">Low margins</div>
            </div>
            
            <ArrowRight className="w-6 h-6 text-red-500/50 hidden md:block" />
            
            <div className="flex-1">
              <div className="w-16 h-16 mx-auto rounded-full bg-red-500/20 border border-red-500/30 flex items-center justify-center mb-3">
                <span className="text-2xl">🕵️‍♂️</span>
              </div>
              <div className="font-medium text-red-400">Multiple Brokers</div>
              <div className="text-xs text-red-400 mt-1">30-40% cut</div>
            </div>
            
            <ArrowRight className="w-6 h-6 text-red-500/50 hidden md:block" />
            
            <div className="flex-1">
              <div className="w-16 h-16 mx-auto rounded-full bg-white/10 flex items-center justify-center mb-3">
                <span className="text-2xl">🏨</span>
              </div>
              <div className="font-medium">Premium Buyer</div>
              <div className="text-xs text-red-400 mt-1">High prices, low quality</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
