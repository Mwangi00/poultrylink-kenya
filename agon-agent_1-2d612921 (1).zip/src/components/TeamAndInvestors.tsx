import { Briefcase, Download, Mail, CheckCircle2, TrendingUp, ShieldCheck } from 'lucide-react';

export default function TeamAndInvestors({ onOpenModal }: { onOpenModal: (type: any) => void }) {
  return (
    <section className="py-24 bg-[#050505] relative overflow-hidden" id="team">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#0B3D2E]/20 via-[#0A0A0A] to-[#0A0A0A] -z-10" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      
      <div className="container mx-auto px-6 relative z-10">
        
        {/* TEAM SECTION */}
        <div className="mb-32">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm text-[#D4AF37] mb-6">
              The Team
            </div>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Built by Operators Who Understand Both Sides of the Market
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-16">
            {/* Founder 1 */}
            <div className="glass-panel p-8 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#0B3D2E] rounded-bl-full opacity-20 transition-transform group-hover:scale-110" />
              <div className="flex items-start gap-6 mb-6">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#0B3D2E] to-[#D4AF37] p-1 shrink-0">
                  <img src="https://ui-avatars.com/api/?name=Alloise+Mwangi&background=0A0A0A&color=D4AF37&size=150" alt="Alloise Mwangi" className="w-full h-full rounded-xl object-cover" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Alloise Mwangi</h3>
                  <p className="text-[#D4AF37] font-medium mb-2">CEO & Co-Founder</p>
                </div>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Alloise leads product, technology, and strategic direction at PoultryLink. With a strong foundation in digital systems and emerging AI tools, he focuses on building scalable infrastructure for Africa's informal markets.
              </p>
              <div className="space-y-2 mb-6">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-400">Technical execution (platform development, automation, AI leverage)</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-400">Business strategy (market design, monetization, partnerships)</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-400">Long-term vision (building trade infrastructure, not just a marketplace)</span>
                </div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl border border-white/5 text-sm italic text-gray-400">
                "Use technology to solve real, grounded problems in African supply chains — starting with trust, payments, and access."
              </div>
            </div>

            {/* Founder 2 */}
            <div className="glass-panel p-8 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37] rounded-bl-full opacity-10 transition-transform group-hover:scale-110" />
              <div className="flex items-start gap-6 mb-6">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#0B3D2E] p-1 shrink-0">
                  <img src="https://ui-avatars.com/api/?name=Benevictor+Muracia&background=0A0A0A&color=D4AF37&size=150" alt="Benevictor Muracia" className="w-full h-full rounded-xl object-cover" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Benevictor Muracia</h3>
                  <p className="text-[#D4AF37] font-medium mb-2">Co-Founder — PR & Market Expansion</p>
                </div>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Benevictor leads communications, partnerships, and stakeholder engagement. He is responsible for building trust across PoultryLink's ecosystem — from farmers and cooperatives to hotels and institutional partners.
              </p>
              <div className="space-y-2 mb-6">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-400">Relationship building across diverse market players</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-400">Brand positioning and public perception</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-400">Partnership development and on-the-ground market engagement</span>
                </div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl border border-white/5 text-sm italic text-gray-400">
                Ensures PoultryLink doesn't just scale — it is trusted, understood, and adopted by the market.
              </div>
            </div>
          </div>

          {/* Combined Edge & Vision */}
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 glass-panel p-8 bg-gradient-to-br from-[#0B3D2E]/20 to-transparent">
              <h4 className="text-xl font-bold mb-4 flex items-center gap-2">
                <ShieldCheck className="text-[#D4AF37] w-6 h-6" /> The Combined Edge
              </h4>
              <p className="text-gray-300 mb-6">
                Together, Alloise and Benevictor bring a tech + trust combination critical for success in Africa's informal economy. This balance allows PoultryLink to operate where most digital platforms fail — bridging real-world trust with digital efficiency.
              </p>
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="bg-[#0A0A0A] p-4 rounded-xl border border-white/5 text-center">
                  <div className="text-[#D4AF37] font-bold mb-1">Tech + AI</div>
                  <div className="text-xs text-gray-400">Platform, automation & scalability</div>
                </div>
                <div className="bg-[#0A0A0A] p-4 rounded-xl border border-white/5 text-center">
                  <div className="text-[#D4AF37] font-bold mb-1">Market Trust</div>
                  <div className="text-xs text-gray-400">Farmers, buyers & relationships</div>
                </div>
                <div className="bg-[#0A0A0A] p-4 rounded-xl border border-white/5 text-center">
                  <div className="text-[#D4AF37] font-bold mb-1">Strategy</div>
                  <div className="text-xs text-gray-400">Business & long-term thinking</div>
                </div>
              </div>
            </div>

            <div className="glass-panel p-8 bg-[#D4AF37] text-black">
              <h4 className="text-xl font-bold mb-4">Why This Team Wins</h4>
              <ul className="space-y-3 font-medium text-black/80">
                <li className="flex items-start gap-2">
                  <span className="text-black mt-1">•</span> Deep understanding of Kenya's informal trade systems
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-black mt-1">•</span> Execution-first mindset (not theory-driven)
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-black mt-1">•</span> Strong local network potential (cooperatives, HoReCa)
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-black mt-1">•</span> Clear division of roles (Tech + PR/Market)
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-black mt-1">•</span> Long-term vision beyond a single product
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 text-center max-w-4xl mx-auto">
            <blockquote className="text-xl md:text-2xl font-medium text-white leading-relaxed italic">
              "To build the digital infrastructure powering trusted agricultural trade across Africa — starting with poultry, and scaling into a continent-wide commerce network where farmers earn fairly, buyers source reliably, and transactions are secure, transparent, and efficient."
            </blockquote>
          </div>
        </div>

        {/* INVESTOR PITCH SECTION */}
        <div className="glass-panel p-8 md:p-12 bg-[#0B3D2E] border-[#D4AF37]/30 relative overflow-hidden rounded-3xl" id="invest">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#D4AF37] rounded-full blur-[120px] opacity-20" />
          
          <div className="relative z-10 grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-sm text-[#D4AF37] mb-6">
                <Briefcase className="w-4 h-4" /> Seed Round Open
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Invest in Africa's Poultry Infrastructure
              </h2>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                We are raising <strong className="text-white">KSh 20M ($150k)</strong> for 15% equity to scale operations in Nairobi, build out our automated compliance engine, and acquire our first 1,000 verified farmers.
              </p>
              
              <div className="space-y-4 mb-10">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-gray-300">Use of Funds</span>
                  <span className="font-bold text-white">Tech (40%), Ops (40%), Mktg (20%)</span>
                </div>
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-gray-300">Target ROI</span>
                  <span className="font-bold text-white">10x in 5 years (Series A target)</span>
                </div>
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-gray-300">Commitments</span>
                  <span className="font-bold text-[#D4AF37]">35% Subscribed</span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <button onClick={() => onOpenModal('investor')} className="bg-[#D4AF37] hover:bg-[#b5952f] text-black px-8 py-4 rounded-full font-bold transition-all flex items-center gap-2">
                  <Mail className="w-5 h-5" /> Request Data Room
                </button>
                <button className="bg-transparent hover:bg-white/10 text-white px-8 py-4 rounded-full font-medium transition-all flex items-center gap-2 border border-white/20">
                  <Download className="w-5 h-5" /> Pitch Deck (PDF)
                </button>
              </div>
            </div>

            <div className="bg-[#050505]/50 backdrop-blur-md rounded-2xl p-8 border border-white/10">
              <TrendingUp className="w-12 h-12 text-[#D4AF37] mb-6" />
              <h3 className="text-2xl font-bold text-white mb-4">Why Invest Now?</h3>
              <p className="text-gray-300 mb-6">
                The East African poultry market is worth KSh 26.3B annually, growing at 8.2% YoY. Yet, it operates entirely offline through fragmented, untrustworthy broker networks.
              </p>
              <p className="text-gray-300">
                PoultryLink is the first mover building a defensible, tech-enabled infrastructure layer that standardizes quality, secures payments, and guarantees delivery. By capturing just 5% of the Nairobi B2B market, we project profitability within 18 months.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
