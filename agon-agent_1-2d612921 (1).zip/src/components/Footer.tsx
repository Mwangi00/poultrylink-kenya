import { Twitter, Linkedin, Mail, MapPin, MessageCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#050505] border-t border-white/10 pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded bg-gradient-to-br from-[#0B3D2E] to-[#D4AF37] flex items-center justify-center font-bold text-white">P</div>
              <span className="text-xl font-bold tracking-tight text-white">Poultry<span className="text-[#D4AF37]">Link</span></span>
            </div>
            <p className="text-gray-400 max-w-sm mb-6">
              East Africa's first verified B2B poultry marketplace connecting smallholder farmers to premium buyers.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                <Twitter className="w-5 h-5 text-gray-400" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                <Linkedin className="w-5 h-5 text-gray-400" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-white mb-4">Contact</h4>
            <ul className="space-y-4">
              <li>
                <a href="https://api.whatsapp.com/send?phone=254707403956" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-[#25D366] transition-colors group">
                  <div className="w-8 h-8 rounded-full bg-[#25D366]/10 flex items-center justify-center group-hover:bg-[#25D366]/20 transition-colors shrink-0">
                    <MessageCircle className="w-4 h-4 text-[#25D366]" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">WhatsApp Business</div>
                    <div className="font-medium">+254 707 403 956</div>
                  </div>
                </a>
              </li>
              <li>
                <a href="mailto:poultrylink.ke@gmail.com" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group">
                  <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white/10 transition-colors shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Email Us</div>
                    <div className="font-medium break-all">poultrylink.ke@gmail.com</div>
                  </div>
                </a>
              </li>
              <li className="flex items-center gap-2 text-gray-400 pt-2">
                <MapPin className="w-4 h-4 shrink-0" /> Nairobi, Kenya
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-white mb-4">Legal</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Supplier Agreement</a></li>
            </ul>
          </div>
        </div>
        
        <div className="text-center pt-8 border-t border-white/10 text-sm text-gray-500">
          © {new Date().getFullYear()} PoultryLink Kenya. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
