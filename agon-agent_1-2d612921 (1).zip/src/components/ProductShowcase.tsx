import { BarChart3, MessageSquare, ShieldCheck, Truck } from 'lucide-react';

export default function ProductShowcase() {
  return (
    <section className="py-24 bg-[#050505] border-y border-white/5 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Infrastructure, Not Just an App</h2>
            <p className="text-gray-400 text-lg mb-8">
              We provide a full-stack operating system for poultry trade, combining intuitive interfaces with robust backend logistics and financial rails.
            </p>
            
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#0B3D2E]/20 flex items-center justify-center shrink-0 border border-[#0B3D2E]/50">
                  <MessageSquare className="w-6 h-6 text-[#D4AF37]" />
                </div>
                <div>
                  <h4 className="text-xl font-bold mb-1">WhatsApp Native</h4>
                  <p className="text-gray-400 text-sm">No new apps to download. Farmers and buyers transact entirely via automated WhatsApp flows.</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#0B3D2E]/20 flex items-center justify-center shrink-0 border border-[#0B3D2E]/50">
                  <BarChart3 className="w-6 h-6 text-[#D4AF37]" />
                </div>
                <div>
                  <h4 className="text-xl font-bold mb-1">Enterprise Dashboard</h4>
                  <p className="text-gray-400 text-sm">For large buyers: manage procurement, track spending, and download compliance reports.</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#0B3D2E]/20 flex items-center justify-center shrink-0 border border-[#0B3D2E]/50">
                  <Truck className="w-6 h-6 text-[#D4AF37]" />
                </div>
                <div>
                  <h4 className="text-xl font-bold mb-1">Logistics Engine</h4>
                  <p className="text-gray-400 text-sm">Automated dispatching to vetted cold-chain transport partners based on route optimization.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="glass-panel p-4 rounded-2xl border border-white/10 bg-[#0A0A0A] shadow-2xl relative z-10 transform lg:rotate-[-2deg] transition-transform hover:rotate-0 duration-500">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
                <div className="text-xs font-medium text-gray-400">Buyer Dashboard — Serena Hotel</div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-white/5 rounded-lg p-4 border border-white/5">
                  <div className="text-xs text-gray-400 mb-1">Monthly Spend</div>
                  <div className="text-lg font-bold">KSh 450,000</div>
                </div>
                <div className="bg-white/5 rounded-lg p-4 border border-white/5">
                  <div className="text-xs text-gray-400 mb-1">Active Orders</div>
                  <div className="text-lg font-bold text-[#D4AF37]">3 Pending</div>
                </div>
                <div className="bg-white/5 rounded-lg p-4 border border-white/5">
                  <div className="text-xs text-gray-400 mb-1">Verified Suppliers</div>
                  <div className="text-lg font-bold text-[#25D366]">12 Active</div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="text-sm font-bold mb-2">Recent Deliveries</div>
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between bg-white/5 p-3 rounded-lg border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#0B3D2E] flex items-center justify-center">
                        <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                      </div>
                      <div>
                        <div className="text-sm font-medium">Kiambu Farm Co-op</div>
                        <div className="text-xs text-gray-400">150 Kgs • Grade A Whole</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold">KSh 67,500</div>
                      <div className="text-xs text-[#25D366]">Completed</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-[#0B3D2E] rounded-full blur-[80px] opacity-40 z-0" />
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-[#D4AF37] rounded-full blur-[80px] opacity-10 z-0" />
          </div>
        </div>
      </div>
    </section>
  );
}
