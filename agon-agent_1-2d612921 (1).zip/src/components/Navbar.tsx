import { useState, useEffect } from 'react';
import { Menu, X, ChevronRight } from 'lucide-react';

export default function Navbar({ onOpenModal }: { onOpenModal: (type: any) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-[#0A0A0A]/90 backdrop-blur-md border-b border-white/10 py-4' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-[#0B3D2E] to-[#D4AF37] flex items-center justify-center font-bold text-white">P</div>
          <span className="text-xl font-bold tracking-tight text-white">Poultry<span className="text-[#D4AF37]">Link</span></span>
        </div>
        
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-300">
          <a href="#solution" className="hover:text-white transition-colors">Platform</a>
          <a href="#how-it-works" className="hover:text-white transition-colors">How it Works</a>
          <a href="#market" className="hover:text-white transition-colors">Market</a>
          <a href="#investors" className="hover:text-[#D4AF37] transition-colors">Investors</a>
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <button onClick={() => onOpenModal('buyer')} className="text-sm font-medium hover:text-white transition-colors">Log In</button>
          <button onClick={() => onOpenModal('farmer')} className="bg-[#0B3D2E] hover:bg-[#0d4d3a] text-white px-5 py-2.5 rounded-full text-sm font-medium transition-all flex items-center gap-2 border border-[#1a5c48]">
            Get Started <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-[#0A0A0A] border-b border-white/10 p-6 flex flex-col gap-4">
          <a href="#solution" onClick={() => setMobileMenuOpen(false)} className="text-lg">Platform</a>
          <a href="#how-it-works" onClick={() => setMobileMenuOpen(false)} className="text-lg">How it Works</a>
          <a href="#investors" onClick={() => setMobileMenuOpen(false)} className="text-lg text-[#D4AF37]">Investors</a>
          <div className="h-px bg-white/10 my-2" />
          <button onClick={() => { onOpenModal('farmer'); setMobileMenuOpen(false); }} className="bg-[#0B3D2E] w-full py-3 rounded-lg text-center font-medium">Get Started</button>
        </div>
      )}
    </header>
  );
}
