import { PieChart, Truck, FileText, Star } from 'lucide-react';

export default function BusinessModel() {
  return (
    <section className="py-24 bg-[#050505] border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Strong Unit Economics</h2>
          <p className="text-gray-400 text-lg">A diversified revenue model that captures value across the entire transaction lifecycle.</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          <div className="glass-panel p-6">
            <PieChart className="w-8 h-8 text-[#D4AF37] mb-4" />
            <h3 className="text-xl font-bold mb-2">6.5% Take Rate</h3>
            <p className="text-sm text-gray-400">Commission charged on the total GMV of every successful transaction through the escrow platform.</p>
          </div>
          <div className="glass-panel p-6">
            <Truck className="w-8 h-8 text-[#D4AF37] mb-4" />
            <h3 className="text-xl font-bold mb-2">Logistics Margin</h3>
            <p className="text-sm text-gray-400">10-15% margin on coordinated cold-chain logistics and last-mile delivery services.</p>
          </div>
          <div className="glass-panel p-6">
            <FileText className="w-8 h-8 text-[#D4AF37] mb-4" />
            <h3 className="text-xl font-bold mb-2">Compliance Fees</h3>
            <p className="text-sm text-gray-400">Flat fees for generating digital health certificates and tax-compliant invoicing for enterprise buyers.</p>
          </div>
          <div className="glass-panel p-6">
            <Star className="w-8 h-8 text-[#D4AF37] mb-4" />
            <h3 className="text-xl font-bold mb-2">Premium Listings</h3>
            <p className="text-sm text-gray-400">Subscription for large cooperatives to get priority matching with high-volume institutional buyers.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
