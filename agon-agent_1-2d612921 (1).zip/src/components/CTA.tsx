export default function CTA({ onOpenModal }: { onOpenModal: (type: any) => void }) {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-[#0B3D2E]/20" />
      <div className="container mx-auto px-6 relative z-10 text-center">
        <h2 className="text-4xl md:text-6xl font-bold mb-8 text-white">Join the Future of Poultry Trade</h2>
        <div className="flex flex-col md:flex-row justify-center items-center gap-4">
          <button onClick={() => onOpenModal('farmer')} className="w-full md:w-auto bg-white text-black px-8 py-4 rounded-full font-bold hover:bg-gray-200 transition-colors">
            For Farmers
          </button>
          <button onClick={() => onOpenModal('buyer')} className="w-full md:w-auto bg-[#0B3D2E] text-white px-8 py-4 rounded-full font-bold border border-[#1a5c48] hover:bg-[#0d4d3a] transition-colors">
            For Buyers
          </button>
          <button onClick={() => onOpenModal('investor')} className="w-full md:w-auto bg-transparent text-[#D4AF37] px-8 py-4 rounded-full font-bold border border-[#D4AF37] hover:bg-[#D4AF37]/10 transition-colors">
            For Investors
          </button>
        </div>
      </div>
    </section>
  );
}
