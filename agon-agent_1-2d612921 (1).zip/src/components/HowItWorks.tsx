import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Smartphone, CheckCircle, Truck, CreditCard, ClipboardList, ScanLine } from 'lucide-react';

export default function HowItWorks() {
  const [activeTab, setActiveTab] = useState<'farmers' | 'buyers'>('buyers');

  const flows = {
    buyers: [
      { icon: <Smartphone />, title: "Browse & Order", desc: "Request specific volumes via WhatsApp or Web." },
      { icon: <CreditCard />, title: "Escrow Payment", desc: "Pay via M-Pesa. Funds are locked securely." },
      { icon: <Truck />, title: "Track Delivery", desc: "Real-time updates on logistics and ETA." },
      { icon: <ScanLine />, title: "Confirm & Trace", desc: "Scan QR code to verify origin and release funds." }
    ],
    farmers: [
      { icon: <CheckCircle />, title: "Get Verified", desc: "Field agents verify farm capacity and health standards." },
      { icon: <ClipboardList />, title: "List Produce", desc: "Update available stock via simple WhatsApp bot." },
      { icon: <Truck />, title: "Pickup Arranged", desc: "Logistics partner collects directly from the farm." },
      { icon: <CreditCard />, title: "Instant Payout", desc: "Receive funds instantly via M-Pesa upon delivery." }
    ]
  };

  return (
    <section className="py-24 bg-[#050505] border-y border-white/5" id="how-it-works">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">How It Works</h2>
          <p className="text-gray-400 text-lg">Seamless experience designed for the realities of African trade.</p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="glass-panel p-1 inline-flex rounded-full">
            <button 
              onClick={() => setActiveTab('buyers')}
              className={`px-8 py-3 rounded-full text-sm font-medium transition-all ${activeTab === 'buyers' ? 'bg-[#0B3D2E] text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
            >
              For Buyers
            </button>
            <button 
              onClick={() => setActiveTab('farmers')}
              className={`px-8 py-3 rounded-full text-sm font-medium transition-all ${activeTab === 'farmers' ? 'bg-[#0B3D2E] text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}
            >
              For Farmers
            </button>
          </div>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-4 gap-6 relative">
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-white/10 -translate-y-1/2 z-0" />
            
            <AnimatePresence mode="wait">
              {flows[activeTab].map((step, i) => (
                <motion.div
                  key={`${activeTab}-${i}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: i * 0.1 }}
                  className="relative z-10 glass-panel p-6 bg-[#0A0A0A] flex flex-col items-center text-center"
                >
                  <div className="w-16 h-16 rounded-full bg-[#0B3D2E] border-4 border-[#050505] flex items-center justify-center text-[#D4AF37] mb-4 shadow-[0_0_15px_rgba(11,61,46,0.5)]">
                    {step.icon}
                  </div>
                  <div className="text-xs font-bold text-[#D4AF37] tracking-wider uppercase mb-2">Step {i + 1}</div>
                  <h3 className="text-lg font-bold mb-2">{step.title}</h3>
                  <p className="text-sm text-gray-400">{step.desc}</p>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
