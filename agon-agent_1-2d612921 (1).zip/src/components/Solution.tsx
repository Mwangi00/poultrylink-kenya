import { motion } from 'framer-motion';
import { CheckCircle2, Lock, Truck, FileCheck, Users } from 'lucide-react';

const features = [
  {
    icon: <Users className="w-6 h-6" />,
    title: "Verified Marketplace",
    desc: "Curated network of vetted farmers and premium buyers."
  },
  {
    icon: <Lock className="w-6 h-6" />,
    title: "M-Pesa Escrow",
    desc: "Funds held securely until delivery is confirmed. Zero payment risk."
  },
  {
    icon: <CheckCircle2 className="w-6 h-6" />,
    title: "Field Verification",
    desc: "On-ground agents ensure quality, health standards, and capacity."
  },
  {
    icon: <Truck className="w-6 h-6" />,
    title: "Logistics Coordination",
    desc: "Optimized routing and cold-chain integration for fresh delivery."
  },
  {
    icon: <FileCheck className="w-6 h-6" />,
    title: "Compliance Automation",
    desc: "Digital health certificates, invoicing, and tax compliance built-in."
  }
];

export default function Solution() {
  return (
    <section className="py-24 relative" id="solution">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#0B3D2E]/20 via-[#0A0A0A] to-[#0A0A0A] -z-10" />
      
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            <span className="text-[#D4AF37]">PoultryLink</span> Fixes This
          </h2>
          <p className="text-gray-400 text-lg">
            We replace the fragmented broker network with a transparent, digital infrastructure that guarantees quality, secures payments, and optimizes logistics.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-panel p-8 hover:border-[#0B3D2E] transition-colors group cursor-pointer"
            >
              <div className="w-12 h-12 rounded-xl bg-[#0B3D2E]/30 flex items-center justify-center mb-6 border border-[#0B3D2E]/50 group-hover:scale-110 transition-transform text-[#D4AF37]">
                {f.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{f.title}</h3>
              <p className="text-gray-400">{f.desc}</p>
            </motion.div>
          ))}
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="glass-panel p-8 bg-gradient-to-br from-[#0B3D2E]/40 to-transparent border-[#0B3D2E] flex flex-col justify-center items-center text-center"
          >
            <h3 className="text-2xl font-bold mb-2 text-[#D4AF37]">100%</h3>
            <p className="text-white font-medium">Traceable Supply Chain</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
