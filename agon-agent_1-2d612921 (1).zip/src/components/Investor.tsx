import { Briefcase, Download, Mail } from 'lucide-react';

export default function Investor({ onOpenModal }: { onOpenModal: (type: any) => void }) {
  return (
    <section className="py-24 bg-[#0B3D2E] relative overflow-hidden" id="investors">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#D4AF37] rounded-full blur-[120px] opacity-20" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-sm text-[#D4AF37] mb-6">
              <Briefcase className="w-4 h-4" /> Seed Round Open
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
              Invest in Africa's Poultry Infrastructure
            </h2>
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              We are raising <strong className="text-white">KSh 20M ($150k)</strong> for 15% equity to scale operations in Nairobi, build out our automated compliance engine, and acquire our first 1,000 verified farmers.
            </p>
            
            <div className="space-y-4 mb-10">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-gray-300">Use of Funds</span>
                <span className="font-bold text-white">Tech (40%), Ops (40%), Mktg (20%)</span>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-gray-300">Target ROI</span>
                <span className="font-bold text-white">10x in 5 years (Series A target)</span>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-gray-300">Commitments</span>
                <span className="font-bold text-[#D4AF37]">35% Subscribed</span>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <button onClick={() => onOpenModal('investor')} className="bg-[#D4AF37] hover:bg-[#b5952f] text-black px-8 py-4 rounded-full font-bold transition-all flex items-center gap-2">
                <Mail className="w-5 h-5" /> Request Data Room
              </button>
              <button className="bg-transparent hover:bg-white/10 text-white px-8 py-4 rounded-full font-medium transition-all flex items-center gap-2 border border-white/20">
                <Download className="w-5 h-5" /> Pitch Deck (PDF)
              </button>
            </div>
          </div>
          
          <div className="glass-panel p-8 bg-[#050505]/80 backdrop-blur-xl border-white/10">
            <h3 className="text-2xl font-bold mb-6">Founder & Vision</h3>
            <div className="flex items-start gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0B3D2E] to-[#D4AF37] p-1">
                <img src="https://ui-avatars.com/api/?name=Alloise+Mwangi&background=0A0A0A&color=D4AF37" alt="Founder" className="w-full h-full rounded-full object-cover" />
              </div>
              <div>
                <h4 className="text-lg font-bold">Alloise Mwangi</h4>
                <p className="text-[#D4AF37] text-sm mb-2">Founder & CEO</p>
                <p className="text-gray-400 text-sm">Ex-Logistics at Sendy, 2nd-generation poultry farmer. Deep understanding of supply chain bottlenecks in East Africa.</p>
              </div>
            </div>
            <blockquote className="border-l-2 border-[#D4AF37] pl-4 italic text-gray-300 text-sm">
              "We aren't just building an app. We are building the trust layer for a multi-billion dollar informal industry. By securing payments and guaranteeing quality, we unlock scale for both farmers and buyers."
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
