import { MapPin } from 'lucide-react';

export default function GoToMarket() {
  return (
    <section className="py-24 bg-[#050505] border-y border-white/5 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Go-To-Market Strategy</h2>
            <p className="text-gray-400 text-lg mb-8">
              Focused execution in high-density corridors before national expansion.
            </p>
            
            <div className="space-y-6">
              <div className="glass-panel p-6 border-l-4 border-l-[#D4AF37]">
                <h4 className="text-xl font-bold mb-2">Phase 1: Nairobi & Kiambu</h4>
                <p className="text-gray-400 text-sm">Focusing on the highest demand concentration (Nairobi hotels/restaurants) and the highest supply concentration (Kiambu farmers).</p>
              </div>
              <div className="glass-panel p-6">
                <h4 className="text-xl font-bold mb-2">Anchor Partners</h4>
                <ul className="text-gray-400 text-sm space-y-2">
                  <li>• <strong>Abattoirs:</strong> Certified processing partners for bulk buyers.</li>
                  <li>• <strong>Hotels:</strong> Pre-signed LOIs with 3 major hotel chains.</li>
                  <li>• <strong>Cooperatives:</strong> Onboarding 50+ members per cluster.</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="relative h-[400px] flex items-center justify-center">
            <div className="absolute inset-0 opacity-20 bg-[url('https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Kenya_location_map.svg/1024px-Kenya_location_map.svg.png')] bg-contain bg-center bg-no-repeat" style={{ filter: 'invert(1)' }} />
            
            <div className="relative z-10 glass-panel p-4 flex items-center gap-3 top-[-40px] left-[-40px] animate-pulse">
              <div className="w-8 h-8 rounded-full bg-[#0B3D2E] flex items-center justify-center">
                <MapPin className="w-4 h-4 text-[#D4AF37]" />
              </div>
              <div>
                <div className="text-sm font-bold">Kiambu</div>
                <div className="text-xs text-gray-400">Supply Hub</div>
              </div>
            </div>
            
            <div className="relative z-10 glass-panel p-4 flex items-center gap-3 top-[40px] left-[20px]">
              <div className="w-8 h-8 rounded-full bg-[#D4AF37] flex items-center justify-center">
                <MapPin className="w-4 h-4 text-black" />
              </div>
              <div>
                <div className="text-sm font-bold">Nairobi</div>
                <div className="text-xs text-gray-400">Demand Hub</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
