import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Problem from './components/Problem';
import Solution from './components/Solution';
import HowItWorks from './components/HowItWorks';
import MarketOpportunity from './components/MarketOpportunity';
import ProductShowcase from './components/ProductShowcase';
import Traction from './components/Traction';
import BusinessModel from './components/BusinessModel';
import GoToMarket from './components/GoToMarket';
import CompetitiveAdvantage from './components/CompetitiveAdvantage';
import TeamAndInvestors from './components/TeamAndInvestors';
import CTA from './components/CTA';
import Footer from './components/Footer';
import LeadModal from './components/LeadModal';

function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'farmer' | 'buyer' | 'investor'>('buyer');

  const openModal = (type: 'farmer' | 'buyer' | 'investor') => {
    setModalType(type);
    setModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white font-sans overflow-x-hidden selection:bg-[#0B3D2E] selection:text-[#D4AF37]">
      <Navbar onOpenModal={openModal} />
      <main>
        <Hero onOpenModal={openModal} />
        <Problem />
        <Solution />
        <HowItWorks />
        <MarketOpportunity />
        <ProductShowcase />
        <Traction />
        <BusinessModel />
        <GoToMarket />
        <CompetitiveAdvantage />
        <TeamAndInvestors onOpenModal={openModal} />
        <CTA onOpenModal={openModal} />
      </main>
      <Footer />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}

export default App;
