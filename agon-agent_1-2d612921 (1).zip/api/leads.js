import supabase from './_supabase.js';
import { Resend } from 'resend';

// Initialize Resend with a fallback to avoid crashing if the key isn't set yet
const resend = new Resend(process.env.RESEND_API_KEY || 're_placeholder');

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { type, name, email, phone, company, message } = req.body;
      
      // Auto-generate UUID
      const id = crypto.randomUUID();
      
      // 1. Save to Database
      const { data, error } = await supabase
        .from('leads')
        .insert({ 
          id,
          type, 
          name, 
          email, 
          phone, 
          company, 
          message,
          created_at: new Date().toISOString()
        })
        .select()
        .single();
        
      if (error) {
        console.error('Supabase insert error:', error);
        throw error;
      }

      // 2. Send Email Notification
      // We only attempt to send the email if the RESEND_API_KEY is actually configured
      if (process.env.RESEND_API_KEY) {
        try {
          const typeLabel = type === 'farmer' ? 'New Farmer Application' : 
                            type === 'buyer' ? 'New Buyer Lead' : 
                            'New Investor Inquiry';
                            
          await resend.emails.send({
            from: 'PoultryLink Notifications <onboarding@resend.dev>', // Using Resend's default testing domain
            to: 'poultrylink.ke@gmail.com',
            subject: `🚨 ${typeLabel}: ${name}`,
            html: `
              <h2>New Lead from PoultryLink Website</h2>
              <p><strong>Type:</strong> ${type.toUpperCase()}</p>
              <p><strong>Name:</strong> ${name}</p>
              <p><strong>Email:</strong> ${email}</p>
              <p><strong>Phone (WhatsApp):</strong> ${phone}</p>
              ${company ? `<p><strong>Company/Farm:</strong> ${company}</p>` : ''}
              ${message ? `<p><strong>Message:</strong><br/>${message}</p>` : ''}
              <br/>
              <p><em>This lead was also saved to your database.</em></p>
            `
          });
          console.log('Email notification sent successfully');
        } catch (emailError) {
          // We log the error but don't fail the API request, 
          // because the data was already safely saved to the database.
          console.error('Failed to send email notification:', emailError);
        }
      } else {
        console.warn('RESEND_API_KEY is not set. Lead saved to DB, but email was not sent.');
      }
      
      return res.status(201).json(data);
    }
    
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}