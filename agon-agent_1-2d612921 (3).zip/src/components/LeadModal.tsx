import { useState } from 'react';
import { X, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase directly in the frontend using the public keys
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://ezlwwgciyseankjjxdel.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_IgJ9AKJuclk0OUDoExQekg_N4TGf1nF';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

export default function LeadModal({ isOpen, onClose, type }: { isOpen: boolean, onClose: () => void, type: 'farmer' | 'buyer' | 'investor' }) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Generate unique ID in the browser
      const id = crypto.randomUUID();
      
      // Insert directly into Supabase from the frontend
      const { error } = await supabase
        .from('leads')
        .insert({ 
          id,
          type, 
          name: formData.name, 
          email: formData.email, 
          phone: formData.phone, 
          company: formData.company, 
          message: formData.message,
          created_at: new Date().toISOString()
        });

      if (error) {
        throw error;
      }

      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
        setFormData({ name: '', email: '', phone: '', company: '', message: '' });
      }, 3000);

    } catch (err) {
      console.error('Failed to submit to Supabase:', err);
      alert('There was an error submitting your request. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const titles = {
    farmer: "Join as a Verified Farmer",
    buyer: "Start Sourcing Poultry",
    investor: "Request Investor Access"
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 md:p-8 w-full max-w-md relative"
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <X className="w-6 h-6" />
        </button>

        {success ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-full bg-[#25D366]/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-[#25D366]" />
            </div>
            <h3 className="text-2xl font-bold mb-2">Request Received</h3>
            <p className="text-gray-400">Our team will be in touch with you shortly via WhatsApp or Email.</p>
          </div>
        ) : (
          <>
            <h3 className="text-2xl font-bold mb-2">{titles[type]}</h3>
            <p className="text-gray-400 text-sm mb-6">Fill out the details below and we'll get back to you within 24 hours.</p>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Full Name</label>
                <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-[#111] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#0B3D2E] focus:ring-1 focus:ring-[#0B3D2E]" placeholder="John Doe" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Email</label>
                  <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-[#111] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#0B3D2E] focus:ring-1 focus:ring-[#0B3D2E]" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Phone (WhatsApp)</label>
                  <input required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full bg-[#111] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#0B3D2E] focus:ring-1 focus:ring-[#0B3D2E]" placeholder="+254 700 000000" />
                </div>
              </div>

              {(type === 'buyer' || type === 'investor') && (
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">{type === 'buyer' ? 'Business/Hotel Name' : 'Firm/Organization'}</label>
                  <input type="text" value={formData.company} onChange={e => setFormData({...formData, company: e.target.value})} className="w-full bg-[#111] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#0B3D2E] focus:ring-1 focus:ring-[#0B3D2E]" placeholder="Company Name" />
                </div>
              )}

              {type === 'investor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Message</label>
                  <textarea rows={3} value={formData.message} onChange={e => setFormData({...formData, message: e.target.value})} className="w-full bg-[#111] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#0B3D2E] focus:ring-1 focus:ring-[#0B3D2E]" placeholder="How can we help?" />
                </div>
              )}

              <button disabled={loading} type="submit" className="w-full bg-[#0B3D2E] hover:bg-[#0d4d3a] text-white font-bold py-3 rounded-lg mt-4 transition-colors disabled:opacity-50">
                {loading ? 'Submitting...' : 'Submit Request'}
              </button>
            </form>
          </>
        )}
      </motion.div>
    </div>
  );
}
